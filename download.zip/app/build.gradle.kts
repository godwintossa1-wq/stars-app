plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace "com.example.stars"; compileSdk 34; defaultConfig { 
  applicationId "com.example.stars"; minSdk 24; targetSdk 34; versionCode 1; versionName "1.0"
}}
dependencies {
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.activity:activity-compose:1.9.2")
  implementation("androidx.compose.ui:ui:1.6.8")
  implementation("androidx.compose.material3:material3:1.2.1")
  implementation("io.coil-kt:coil-compose:2.7.0")
}