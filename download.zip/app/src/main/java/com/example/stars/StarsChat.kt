package com.example.stars

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StarsChat() {
    Scaffold(bottomBar = {
        Row {
            TextField(value = "", onValueChange = {})
            Button(onClick = { /*TODO*/ }) {
                Text("Send")
            }
        }
    }) { paddingValues ->
        LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = paddingValues) {
            items(10) { index ->
                Column {
                    Text("Message $index")
                    AsyncImage(model = "https://picsum.photos/200/300?random=$index", contentDescription = null)
                }
            }
        }
    }
}