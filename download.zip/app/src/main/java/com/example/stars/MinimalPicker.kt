package com.example.stars

import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MinimalPicker() {
    ModalBottomSheet(onDismissRequest = { /*TODO*/ }) {
        Row {
            for (i in 1..6) {
                AsyncImage(model = "https://picsum.photos/300?random=$i", contentDescription = null)
            }
        }
    }
}