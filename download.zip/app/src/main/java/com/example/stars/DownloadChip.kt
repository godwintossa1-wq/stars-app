package com.example.stars

import android.widget.Toast
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

@Composable
fun DownloadChip() {
    val context = LocalContext.current
    Button(onClick = { 
        Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
    }) {
        Text("Saved")
    }
}